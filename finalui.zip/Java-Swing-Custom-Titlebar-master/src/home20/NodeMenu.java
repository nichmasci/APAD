/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package home20;

import java.util.ArrayList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

/**
 *
 * @author Nick Masci
 */
public class NodeMenu extends JPopupMenu {;
    JMenuItem safe;
    JMenuItem threat;
    JMenuItem kill;
    JMenuItem invalid;
    JMenuItem remove;
    public NodeMenu(ComputerNodeButton thisNode/*, ArrayList<ComputerNodeButton> nodes*/) {
        safe = new JMenuItem("Mark safe (DEBUG)");
        safe.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.markSafe();
            }
        });
        
        threat = new JMenuItem("Mark as threat");
        threat.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.markThreat();
            }
        });
        
        kill = new JMenuItem("Block this device");
        kill.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.block();
            }
        });
        invalid = new JMenuItem("Mark invalid (DEBUG)");
        invalid.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.markInvalid();
            }
        });
        //remove = new JMenuItem("Remove this node");
        //remove.addActionListener(new java.awt.event.ActionListener(){
        //    public void actionPerformed(java.awt.event.ActionEvent evt) {
        //        nodes.remove(thisNode);
        //    }
        //});
        add(safe);
        add(threat);
        add(kill);
        add(invalid);
        //add(remove);
    }
    
    //public ComputerNodeButton getInvoker()
    //{
        //return ComputerNodeButton inv;
    //}
}

/*
ComputerNodeButton thisNode = (ComputerNodeButton) evt.getSource();
        
        JPopupMenu popup = new JPopupMenu();
        
        JMenuItem safe;
        JMenuItem threat;
        JMenuItem kill;
        JMenuItem remove;
        
        safe = new JMenuItem("Mark safe (DEBUG)");
        safe.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.markSafe();
            }
        });
        
        threat = new JMenuItem("Mark as threat");
        threat.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.markThreat();
            }
        });
        
        kill = new JMenuItem("Block this device");
        kill.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.block();
            }
        });
        remove = new JMenuItem("Remove this node");
        remove.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNode.markInvalid();
            }
        });
        add(safe);
        add(threat);
        add(kill);
        add(remove);
*/
