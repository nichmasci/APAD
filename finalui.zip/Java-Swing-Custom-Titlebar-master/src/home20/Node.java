/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package home20;

/**
 *
 * @author Nick Masci
 */
public class Node{
    String ip; 
    String MAC; 
    int state; 
    int x; 
    int y;

    public Node(String nodeIP, String nodeMAC, int nodeState, int nodeX, int nodeY){
        ip = nodeIP;
        MAC = nodeMAC;
        state = nodeState;
        x = nodeX;
        y = nodeY;
    }
    
    public void setState(int newState){
        this.state = newState;
    }
    /* This might need to be moved to Home20
    public void drawNode(Node node){
        javax.swing.JButton thisNode = new javax.swing.JButton();
        
        thisNode.setText("IP: " + node.ip + "\nMAC: " + node.MAC + "\nCurrent State: " + node.state);
        thisNode.setLocation(node.x, node.y);
        
        thisNode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thisNodeMouseClicked(evt);
            }
        });
        thisNode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNodeActionPerformed(evt);
            }
        });
        
        pnlSettings.setLayout();
    }
    // This might need to be moved to Home20
    */
}