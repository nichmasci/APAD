package home20;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class DynamicGrid{
    public DynamicGrid(int nodes) { 
        //nodes = 10; // This value can be changed to any integer.
        int rows = (int)Math.sqrt(nodes);  // If possible, generates a perfect square
        int columns = rows;                // The program seems to know what to do with imperfect squares.

        JFrame frame = new JFrame("Grid Layout");
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(rows, columns, 5, 5));

        ArrayList<JButton> nodeList = new ArrayList<JButton>();
        for(int i = 1; i <= nodes; i++)     // For now, just populate with meaningless buttons
        {
            nodeList.add(new JButton(("Node " + Integer.toString(i))));
        }

        panel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT); // The nodes will be created from left to right
        for(JButton node : nodeList)
        {
            panel.add(node);
            node.setBackground(Color.GREEN);   // Makes all nodes green
        }

        //int attacker = (int)(Math.random() * nodes);     // Turns a random node red
        //nodeList.get(attacker).setBackground(Color.RED);
        
        frame.add(panel, "card1");
    }

    //public static void main(String[] args)
    //{
    //    DynamicGrid grid = new DynamicGrid(10);
    //}

}