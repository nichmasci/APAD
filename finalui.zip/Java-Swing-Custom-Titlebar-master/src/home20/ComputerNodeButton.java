/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package home20;

import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

/**
 *
 * @author Nick Masci
 */
public class ComputerNodeButton extends JLabel{
    protected String ip; 
    protected String mac; 
    protected int state; 
    //protected int x; 
    //protected int y;

    //NodeMenu popup = new NodeMenu();
    
    
    public ComputerNodeButton(){ //Default Constructor
        ip = "Undefined IP";
        mac = "Undefined MAC";
        state = -1;
        //this.setComponentPopupMenu(popup);
    }
    
    public ComputerNodeButton(String nodeIP, String nodeMAC, int nodeState/*, int nodeX, int nodeY*/){
        ip = nodeIP;
        mac = nodeMAC;
        state = nodeState;
        //x = nodeX;
        //y = nodeY;
        //this.setComponentPopupMenu(popup);
    }
    
    public String getIP(){
        return this.ip;
    }
    
    public String getMAC(){
        return this.mac;
    }
    
    public int getState(){
        return this.state;
    }
    
    public void markSafe(){    // This is probably just a debug function.
        this.state = 0; 
    }
    
    public void markThreat(){  // For now, this will be done via the context menu, 
        this.state = 1; // but should be automatically done by the program in the end product
    }
    
    public void block(){       // For now, just turn the node gray. Later on, it will
        this.state = 2;// actually block the device, then, if it cannot be pinged, turn it gray.
    }
    
    public void markInvalid(){ // Purely a debug function. Won't be used in final product.
        this.state = -1;
    }
    
    public String toString(){
        return "IP: " + this.ip + ".. MAC: " + this.mac;
    }
    
    public void setState(int newState){
        this.state = newState;
    }
    
    /* This might need to be moved to Home20
    public void drawNode(Node node){
        javax.swing.JButton thisNode = new javax.swing.JButton();
        
        thisNode.setText("IP: " + node.ip + "\nMAC: " + node.MAC + "\nCurrent State: " + node.state);
        thisNode.setLocation(node.x, node.y);
        
        thisNode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                thisNodeMouseClicked(evt);
            }
        });
        thisNode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thisNodeActionPerformed(evt);
            }
        });
        
        pnlSettings.setLayout();
    }
    // This might need to be moved to Home20
    */
}


/*class NodeMenu extends JPopupMenu {
    JMenuItem threat;
    JMenuItem kill;
    JMenuItem remove;
    public NodeMenu() {
        threat = new JMenuItem("Mark as threat");
        add(threat);
        threat.addActionListener(new java.awt.event.ActionListener(){
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                this.markThreat();
            }
        });
        kill = new JMenuItem("Block this device");
        add(kill);
        remove = new JMenuItem("Remove this node");
        add(remove);
    }
}*/

