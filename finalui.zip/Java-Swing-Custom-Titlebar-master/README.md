# Java Swing Custom Titlebar

A project to showcase an OS aware Title bar to replace the default swing title bar which you may be able to customize and add more components. Have a look

![](sc1.png)
